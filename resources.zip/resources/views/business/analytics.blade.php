@extends('layouts.business')

@section('content')
<div class="card">
    <h2>Business Analytics</h2>

    <ul>
        <li>Total Orders: 120</li>
        <li>Monthly Revenue: ₹75,000</li>
        <li>Top Product: Wheat Flour</li>
        <li>Customer Satisfaction: ⭐⭐⭐⭐☆</li>
    </ul>
</div>
@endsection
