@extends('layouts.business')

@section('content')
<div class="card">
    <h2>Business Network</h2>

    <p>Connect and collaborate with nearby businesses</p>

    <ul>
        <li>ABC Traders – Grocery Supplier</li>
        <li>FreshFarm Pvt Ltd – Wholesale Vegetables</li>
        <li>LocalMart – Retail Partner</li>
    </ul>
</div>
@endsection
