<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Appointments - LocalConnect Pro</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    @include('components.styles')

    <style>
        /* Appointments Specific Styles */
        .appointments-grid {
            display: grid;
            gap: 16px;
        }

        .appointment-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            transition: all 0.2s;
        }

        .appointment-card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .appointment-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 16px;
        }

        .client-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .client-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, #2563eb, #7c3aed);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
        }

        .client-details h3 {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 4px;
        }

        .client-details p {
            font-size: 13px;
            color: #64748b;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-badge.confirmed {
            background: #d1fae5;
            color: #065f46;
        }

        .status-badge.pending {
            background: #fef3c7;
            color: #92400e;
        }

        .status-badge.completed {
            background: #dbeafe;
            color: #1e40af;
        }

        .status-badge.cancelled {
            background: #fee2e2;
            color: #991b1b;
        }

        .appointment-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 16px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 8px;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: #475569;
        }

        .detail-item i {
            color: #2563eb;
            width: 20px;
        }

        .appointment-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .filter-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            border-bottom: 2px solid #e2e8f0;
        }

        .filter-tab {
            padding: 12px 20px;
            background: none;
            border: none;
            border-bottom: 2px solid transparent;
            color: #64748b;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: -2px;
        }

        .filter-tab:hover {
            color: #2563eb;
        }

        .filter-tab.active {
            color: #2563eb;
            border-bottom-color: #2563eb;
        }
    </style>
</head>

<body>
    @include('components.navbar', [
    'title' => 'Appointments',
    'searchPlaceholder' => 'Search appointments...',
    'userInitials' => 'JD'
    ])

    @include('components.sidebar', [
    'menuItems' => [
    ['icon' => 'th-large', 'label' => 'Dashboard Overview', 'route' => 'professional', 'active' => false],
    ['icon' => 'briefcase', 'label' => 'My Services', 'route' => 'my-services', 'active' => false],
    ['icon' => 'calendar-check', 'label' => 'Appointments', 'route' => 'appointments', 'active' => true],
    ['icon' => 'dollar-sign', 'label' => 'My Earnings', 'route' => 'earnings', 'active' => false],
    ['icon' => 'star', 'label' => 'Reviews & Ratings', 'route' => 'reviews', 'active' => false],
    ['icon' => 'comments', 'label' => 'Messages', 'route' => 'messages', 'active' => false],
    ['icon' => 'sign-out-alt', 'label' => 'Logout', 'route' => 'logout', 'active' => false]
    ]
    ])

    <main class="main-content">
        <div>
            <h1 style="font-size: 28px; font-weight: 700; margin-bottom: 8px;">Appointments</h1>
            <p style="color: #64748b; margin-bottom: 32px;">Manage your appointments and bookings</p>

            <!-- Filter Tabs -->
            <div class="filter-tabs">
                <button class="filter-tab active" onclick="filterAppointments('all')">All</button>
                <button class="filter-tab" onclick="filterAppointments('pending')">Pending</button>
                <button class="filter-tab" onclick="filterAppointments('confirmed')">Confirmed</button>
                <button class="filter-tab" onclick="filterAppointments('completed')">Completed</button>
                <button class="filter-tab" onclick="filterAppointments('cancelled')">Cancelled</button>
            </div>

            <!-- Appointments Grid -->
            <div class="appointments-grid" id="appointments-container">
                <div style="text-align: center; padding: 48px;">
                    <i class="fas fa-spinner fa-spin" style="font-size: 32px; color: #cbd5e1;"></i>
                    <p style="color: #94a3b8; margin-top: 16px;">Loading appointments...</p>
                </div>
            </div>
        </div>
    </main>

    @include('components.scripts')

    <script>
        let allAppointments = [];
        let currentFilter = 'all';

        document.addEventListener('DOMContentLoaded', function() {
            loadAppointments();
        });

        // Load appointments from API
        async function loadAppointments() {
            try {
                const response = await fetch(`${API_BASE}/professional/appointments`, {
                    method: 'GET',
                    headers: authHeaders
                });

                if (!response.ok) throw new Error('Failed to load appointments');

                allAppointments = await response.json();
                renderAppointments(allAppointments);
            } catch (error) {
                console.error('Error loading appointments:', error);
                showEmptyState('No appointments found');
            }
        }

        // Render appointments
        function renderAppointments(appointments) {
            const container = document.getElementById('appointments-container');

            if (appointments.length === 0) {
                showEmptyState('No appointments found');
                return;
            }

            container.innerHTML = appointments.map(apt => `
                <div class="appointment-card">
                    <div class="appointment-header">
                        <div class="client-info">
                            <div class="client-avatar">${apt.client_name ? apt.client_name.charAt(0).toUpperCase() : 'C'}</div>
                            <div class="client-details">
                                <h3>${apt.client_name || 'Client'}</h3>
                                <p>${apt.service_name || 'Service'}</p>
                            </div>
                        </div>
                        <span class="status-badge ${apt.status || 'pending'}">${(apt.status || 'pending').toUpperCase()}</span>
                    </div>
                    
                    <div class="appointment-details">
                        <div class="detail-item">
                            <i class="fas fa-calendar"></i>
                            <span>${apt.date || 'N/A'}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-clock"></i>
                            <span>${apt.time || 'N/A'}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-rupee-sign"></i>
                            <span>₹${apt.price || '0'}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${apt.location || 'N/A'}</span>
                        </div>
                    </div>

                    <div class="appointment-actions">
                        ${apt.status === 'pending' ? `
                            <button class="btn btn-primary" onclick="updateAppointmentStatus(${apt.id}, 'confirmed')">
                                <i class="fas fa-check"></i> Confirm
                            </button>
                            <button class="btn btn-danger" onclick="updateAppointmentStatus(${apt.id}, 'cancelled')">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                        ` : ''}
                        ${apt.status === 'confirmed' ? `
                            <button class="btn btn-primary" onclick="updateAppointmentStatus(${apt.id}, 'completed')">
                                <i class="fas fa-check-circle"></i> Mark Complete
                            </button>
                        ` : ''}
                        <button class="btn btn-outline" onclick="viewAppointmentDetails(${apt.id})">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                    </div>
                </div>
            `).join('');
        }

        // Filter appointments
        function filterAppointments(status) {
            currentFilter = status;

            // Update active tab
            document.querySelectorAll('.filter-tab').forEach(tab => tab.classList.remove('active'));
            event.target.classList.add('active');

            // Filter and render
            const filtered = status === 'all' ?
                allAppointments :
                allAppointments.filter(apt => apt.status === status);

            renderAppointments(filtered);
        }

        // Update appointment status
        async function updateAppointmentStatus(id, status) {
            try {
                const response = await fetch(`${API_BASE}/professional/appointments/${id}`, {
                    method: 'PUT',
                    headers: authHeaders,
                    body: JSON.stringify({
                        status: status
                    })
                });

                if (!response.ok) throw new Error('Failed to update appointment');

                alert(`Appointment ${status} successfully!`);
                loadAppointments();
            } catch (error) {
                console.error('Error updating appointment:', error);
                alert('Failed to update appointment');
            }
        }

        // View appointment details
        function viewAppointmentDetails(id) {
            const appointment = allAppointments.find(apt => apt.id === id);
            if (appointment) {
                alert(`Appointment Details:\n\nClient: ${appointment.client_name}\nService: ${appointment.service_name}\nDate: ${appointment.date}\nTime: ${appointment.time}\nStatus: ${appointment.status}`);
            }
        }

        // Show empty state
        function showEmptyState(message) {
            const container = document.getElementById('appointments-container');
            container.innerHTML = `
                <div style="text-align: center; padding: 64px 32px; background: white; border-radius: 12px;">
                    <i class="fas fa-calendar-times" style="font-size: 64px; color: #cbd5e1; margin-bottom: 16px;"></i>
                    <h3 style="font-size: 20px; font-weight: 600; color: #1e293b; margin-bottom: 8px;">No Appointments</h3>
                    <p style="color: #64748b;">${message}</p>
                </div>
            `;
        }
    </script>
</body>

</html>