@extends('layouts.resident')

@section('content')
<h2>Welcome, Resident 👋</h2>

<div class="stats-grid">
    <x-stats-card title="Active Bookings" value="3" />
    <x-stats-card title="Nearby Professionals" value="12" />
    <x-stats-card title="Pending Requests" value="1" />
</div>
@endsection
