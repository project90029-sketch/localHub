@extends('layouts.resident')

@section('content')
<h2>Messages</h2>

<div class="card">
    <p><strong>Electrician:</strong> I will arrive at 4 PM.</p>
</div>

<div class="card">
    <p><strong>Plumber:</strong> Please confirm your address.</p>
</div>
@endsection
