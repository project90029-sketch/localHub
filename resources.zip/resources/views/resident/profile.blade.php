@extends('layouts.resident')

@section('content')
<h2>My Profile</h2>

<form class="form">
    <div class="form-group">
        <label>Name</label>
        <input type="text" value="{{ auth()->user()->name }}">
    </div>

    <div class="form-group">
        <label>Email</label>
        <input type="email" value="{{ auth()->user()->email }}">
    </div>

    <div class="form-group">
        <label>Phone</label>
        <input type="text" placeholder="Enter phone number">
    </div>

    <button class="btn-primary">Update Profile</button>
</form>
@endsection
